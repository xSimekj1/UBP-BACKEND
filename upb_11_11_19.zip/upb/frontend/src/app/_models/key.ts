export class KeyPair {
    privateK: string;
    publicK: string;

    constructor() {
      this.privateK = '';
      this.publicK = '';
    }
}
