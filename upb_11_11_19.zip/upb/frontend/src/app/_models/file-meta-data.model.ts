export interface FileMetadata {
    id: number;
    filename: string;
    senderUsername: string;
}
