package team.project.upb.api.model;

public class PasswordJSON {

    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
