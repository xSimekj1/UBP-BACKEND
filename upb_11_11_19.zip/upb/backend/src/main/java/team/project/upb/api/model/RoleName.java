package team.project.upb.api.model;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
